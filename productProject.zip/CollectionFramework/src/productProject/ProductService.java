package productProject;

import java.util.Collections;
import java.util.Map;

public class ProductService {
	
	private Map<String,Product> products;
	
	ProductService(Map<String,Product> products)
	{
		this.products=products;
	}
	
	public void StoreProducts() // a
	{
		for(Product product : products.values())
		{
			System.out.println(product);
		}
	}
	
	
	
	public void AccessProducts()//b
	{
		for(Map.Entry<String,Product> product :products.entrySet())
		{
			System.out.println(product.getKey() + "-->" + product.getValue());
		}
	}
	
	public void CountMobileProducts()//f
	{
		int count=0;
		for(Map.Entry<String,Product> product :products.entrySet())
		{
			
			 if(product.getValue() instanceof Mobile) {
				 System.out.println(product.getKey() + "-->" + product.getValue());
			count++;
			
		}
		
	   }
		System.out.println("Mobile products are :" + count);
	
	}
	
	
	public void AccessAllShirtProducts()//e
	{
		
		for(Map.Entry<String,Product> product :products.entrySet())
		{
			
			 if(product.getValue() instanceof Shirt) {
				 System.out.println(product.getKey() + "-->" + product.getValue());
			
			
		}
		
	   }
	}		
		
		public void AccessAllMobileProducts()//d
		{
			
			for(Map.Entry<String,Product> product :products.entrySet())
			{
				
				 if(product.getValue() instanceof Mobile) {
					 System.out.println(product.getKey() + "-->" + product.getValue());
				
				
			}
			
		   }
		}		
			public void CountShirtProducts()//g
			{
				int count=0;
				for(Map.Entry<String,Product> product :products.entrySet())
				{
					
					 if(product.getValue() instanceof Shirt) {
						 System.out.println(product.getKey() + "-->" + product.getValue());
					count++;
					
				}
				
			   }
				System.out.println("Shirt products are :" + count);
			
			}
			
			public void CountShirtProductBySize(int givensize)//h
			{
				int count =0;
				for(Map.Entry<String,Product> product :products.entrySet())
				{
					if(product.getValue() instanceof Shirt)
					{
						Shirt s=(Shirt) product.getValue();
						if(s.size==givensize)
							count++;
					}
				}
				System.out.println("count of given size shirt is :" + count);
			}
			
			public void AccessShirtProductBySizeAndBrand(int givensize, String givenbrand)//i
			{
				
				for(Map.Entry<String,Product> product :products.entrySet())
				{
					if(product.getValue() instanceof Shirt)
					{
						Shirt s=(Shirt) product.getValue();
						if(s.size==givensize && s.brand.equalsIgnoreCase(givenbrand)) {
						System.out.println(product);
						}		
					}
				}
	
			}
			
			public void AccessShirtProductBySizeAndPrice(int givensize, int givenprice)//i
			{
				
				for(Map.Entry<String,Product> product :products.entrySet())
				{
					if(product.getValue() instanceof Shirt)
					{
						Shirt s=(Shirt) product.getValue();
						if(s.size==givensize && s.price>=givenprice) {
						System.out.println(product);
						}		
					}
				}
	
			}
			
			public void AccessShirtByPriceLowToHigh()
			{

				for(Map.Entry<String,Product> product :products.entrySet())
				{
					if(product.getValue() instanceof Shirt)
					{
						Collections.sort(Shirt, new PriceComparator());
					}
			}
}

}
