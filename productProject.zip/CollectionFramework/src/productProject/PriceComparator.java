package productProject;

import java.util.Comparator;

public class PriceComparator implements Comparator<Shirt>{



	@Override
	public int compare(Shirt o1, Shirt o2) {
		// TODO Auto-generated method stub
		return Integer.compare(o1.price, o2.price);
	}

}
